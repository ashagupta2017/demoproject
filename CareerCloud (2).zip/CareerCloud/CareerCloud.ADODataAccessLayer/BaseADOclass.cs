﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace CareerCloud.ADODataAccessLayer
{
	public class BaseADOclass
	{
		protected string connstr;
		public BaseADOclass()
		{
		connstr = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
		}
		

	}
}
