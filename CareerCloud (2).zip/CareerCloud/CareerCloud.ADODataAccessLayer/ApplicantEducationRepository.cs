﻿using CareerCloud.DataAccessLayer;
using CareerCloud.Pocos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq.Expressions;
using System.Configuration;
using System.Data.SqlClient;

namespace CareerCloud.ADODataAccessLayer
{
	public class ApplicantEducationRepository : BaseADOclass, IDataRepository<ApplicantEducationPoco>
	{
		public void Add(params ApplicantEducationPoco[] items)
		{
			using (SqlConnection conn = new SqlConnection(connstr))
			{
				
				SqlCommand cmd = new SqlCommand();
				cmd.Connection = conn;
				
				foreach (ApplicantEducationPoco pocos in items)

				{ 
					cmd.CommandText = @" INSERT INTO[dbo].[Applicant_Educations]
												   ([Id]
												   ,[Applicant]
												   ,[Major]
												   ,[Certificate_Diploma]
												   ,[Start_Date]
												   ,[Completion_Date]
												   ,[Completion_Percent])

											 VALUES
												   ( @Id
												   ,@Applicant
												   ,@Major
												   ,@Certificate_Diploma
												   ,@Start_Date
												   ,@Completion_Date
												   ,@Completion_Percent) ";

					cmd.Parameters.AddWithValue("@Id", pocos.Id);
					cmd.Parameters.AddWithValue("@Applicant", pocos.Applicant);
					cmd.Parameters.AddWithValue("@Major", pocos.Major);
					cmd.Parameters.AddWithValue("@Certificate_Diploma", pocos.CertificateDiploma);
					cmd.Parameters.AddWithValue("@Start_Date", pocos.StartDate);
					cmd.Parameters.AddWithValue("@Completion_Date", pocos.CompletionDate);
					cmd.Parameters.AddWithValue("@Completion_Percent", pocos.CompletionPercent);

					conn.Open();
					cmd.ExecuteNonQuery();
					conn.Close();

				}
			}
		}

			public void CallStoredProc(string name, params Tuple<string, string>[] parameters)
		{
			throw new NotImplementedException();
		}

		public IList<ApplicantEducationPoco> GetAll(params Expression<Func<ApplicantEducationPoco, object>>[] navigationProperties)
		{
			using (SqlConnection conn = new SqlConnection(connstr))
			{
			
				SqlCommand cmd = new SqlCommand();
				cmd.Connection = conn;
				cmd.CommandText = @"     SELECT [Id]
											  ,[Applicant]
											  ,[Major]
											  ,[Certificate_Diploma]
											  ,[Start_Date]
											  ,[Completion_Date]
											  ,[Completion_Percent]
											  ,[Time_Stamp] 
												FROM[dbo].[Applicant_Educations] ";
				int counter = 0;
				ApplicantEducationPoco[] pocos = new ApplicantEducationPoco[500];

				conn.Open();
				SqlDataReader sqrd = cmd.ExecuteReader();

				while (sqrd.Read())
				{
					ApplicantEducationPoco poco = new ApplicantEducationPoco();
					poco.Id = sqrd.GetGuid(0);
					poco.Applicant = sqrd.GetGuid(1);
					poco.Major = sqrd.GetString(2);
					poco.CertificateDiploma = sqrd.GetString(3);
					poco.StartDate = sqrd.GetDateTime(4);
					poco.CompletionDate = sqrd.GetDateTime(5);
					poco.CompletionPercent = sqrd.GetByte(6);
					poco.TimeStamp = (byte[])sqrd[7];

					pocos[counter] = poco;

					counter++;

				
				}
				return pocos.Where(a => a != null).ToList();

				

			}
			
		}

		public IList<ApplicantEducationPoco> GetList(Func<ApplicantEducationPoco, bool> where, params Expression<Func<ApplicantEducationPoco, object>>[] navigationProperties)
		{
			throw new NotImplementedException();
		}

		public ApplicantEducationPoco GetSingle(Func<ApplicantEducationPoco, bool> where, params Expression<Func<ApplicantEducationPoco, object>>[] navigationProperties)
		{
			ApplicantEducationPoco[] pocos = GetAll().ToArray();
			return pocos.Where(where).ToList().FirstOrDefault();

		}

		public void Remove(params ApplicantEducationPoco[] items)
		{
			using (SqlConnection conn = new SqlConnection(connstr))
			{
				SqlCommand cmd = new SqlCommand();

				cmd.Connection = conn;
				foreach (var poco in items)
				{
					cmd.CommandText = @" DELETE FROM [dbo].[Applicant_Educations]
									   WHERE ([Id] = @Id) ";

					cmd.Parameters.AddWithValue ( "@Id", poco.Id);

					conn.Open();
					cmd.ExecuteNonQuery();
					conn.Close();
				}
			}

		}

		public void Update(params ApplicantEducationPoco[] items)
		{
			using (SqlConnection conn = new SqlConnection(connstr))
			{
				
				SqlCommand cmd = new SqlCommand();
				cmd.Connection = conn;
				
				foreach (var poco in items)
				{
					cmd.CommandText = @" UPDATE [dbo].[Applicant_Educations]
											   SET [Id] = @Id
												  ,[Applicant] = @Applicant
												  ,[Major] = @Major
												  ,[Certificate_Diploma] = @CertificateDiploma
												  ,[Start_Date] = @StartDate
												  ,[Completion_Date] = @CompletionDate
												  ,[Completion_Percent] = @CompletionPercent
											 WHERE [Id] = @Id ";

					cmd.Parameters.AddWithValue("@Id", poco.Id);
					cmd.Parameters.AddWithValue("@Applicant", poco.Applicant);
					cmd.Parameters.AddWithValue("@Major", poco.Major);
					cmd.Parameters.AddWithValue("@CertificateDiploma", poco.CertificateDiploma);
					cmd.Parameters.AddWithValue("@StartDate", poco.StartDate);
					cmd.Parameters.AddWithValue("@CompletionDate", poco.CompletionDate);
					cmd.Parameters.AddWithValue("@CompletionPercent", poco.CompletionPercent);

					conn.Open();
					cmd.ExecuteNonQuery();
					conn.Close();
				}

		
			}
		}

	}
}

