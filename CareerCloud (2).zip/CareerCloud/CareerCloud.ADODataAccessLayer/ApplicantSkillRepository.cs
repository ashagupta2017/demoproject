﻿using CareerCloud.DataAccessLayer;
using CareerCloud.Pocos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq.Expressions;
using System.Data.SqlClient;

namespace CareerCloud.ADODataAccessLayer
{
	public class ApplicantSkillRepository : BaseADOclass, IDataRepository<ApplicantSkillPoco>
	{
		public void Add(params ApplicantSkillPoco[] items)
		{

			using (SqlConnection conn = new SqlConnection(connstr))
			{
				SqlCommand cmd = new SqlCommand();
				cmd.Connection = conn;

				foreach (ApplicantSkillPoco pocos in items)

				{
					cmd.CommandText = @" INSERT INTO[dbo].[Applicant_Skills]
										   ([Id]
										   ,[Applicant]
										   ,[Skill]
										   ,[Skill_Level]
										   ,[Start_Month]
										   ,[Start_Year]
										   ,[End_Month]
										   ,[End_Year])
									 VALUES
										   ( @Id
										   ,@Applicant
										   ,@Skill
										   ,@Skill_Level
										   ,@Start_Month
										   ,@Start_Year
										   ,@End_Month
										   ,@End_Year) ";

					cmd.Parameters.AddWithValue("@Id", pocos.Id);
					cmd.Parameters.AddWithValue("@Applicant", pocos.Applicant);
					cmd.Parameters.AddWithValue("@Skill", pocos.Skill);
					cmd.Parameters.AddWithValue("@Skill_Level", pocos.SkillLevel);
					cmd.Parameters.AddWithValue("@Start_Month", pocos.StartMonth);
					cmd.Parameters.AddWithValue("@Start_Year", pocos.StartYear);
					cmd.Parameters.AddWithValue("@End_Month", pocos.EndMonth);
					cmd.Parameters.AddWithValue("@End_Year", pocos.EndYear);


					conn.Open();
					cmd.ExecuteNonQuery();
					conn.Close();

				}
			}
		}
		public void CallStoredProc(string name, params Tuple<string, string>[] parameters)
		{
			throw new NotImplementedException();
		}

		public IList<ApplicantSkillPoco> GetAll(params Expression<Func<ApplicantSkillPoco, object>>[] navigationProperties)
		{
			using (SqlConnection conn = new SqlConnection(connstr))
			{

				SqlCommand cmd = new SqlCommand();
				cmd.Connection = conn;

				cmd.CommandText = @" SELECT [Id]
									  ,[Applicant]
									  ,[Skill]
									  ,[Skill_Level]
									  ,[Start_Month]
									  ,[Start_Year]
									  ,[End_Month]
									  ,[End_Year]
									  ,[Time_Stamp]
								  FROM [dbo].[Applicant_Skills] ";
				int counter = 0;

				ApplicantSkillPoco[] pocos = new ApplicantSkillPoco[500];

				conn.Open();
				SqlDataReader sqrd = cmd.ExecuteReader();

				while (sqrd.Read())
				{
					ApplicantSkillPoco poco = new ApplicantSkillPoco();

					poco.Id = sqrd.GetGuid(0);
					poco.Applicant = sqrd.GetGuid(1);
					poco.Skill = sqrd.GetString(2);
					poco.SkillLevel = sqrd.GetString(3);
					poco.StartMonth = sqrd.GetByte(4);
					poco.StartYear = sqrd.GetInt32(5);
					poco.EndMonth = sqrd.GetByte(6);
					poco.EndYear = sqrd.GetInt32(7);
					poco.TimeStamp = (byte[])sqrd.GetValue(8);

					pocos[counter] = poco;
					counter++;

				}
				return pocos.Where(a => a != null).ToList();


			}
		}

		public IList<ApplicantSkillPoco> GetList(Func<ApplicantSkillPoco, bool> where, params Expression<Func<ApplicantSkillPoco, object>>[] navigationProperties)
		{
			throw new NotImplementedException();
		}

		public ApplicantSkillPoco GetSingle(Func<ApplicantSkillPoco, bool> where, params Expression<Func<ApplicantSkillPoco, object>>[] navigationProperties)
		{
			ApplicantSkillPoco[] pocos = GetAll().ToArray();
			return pocos.Where(where).ToList().FirstOrDefault();
		}

		public void Remove(params ApplicantSkillPoco[] items)
		{
			using (SqlConnection conn = new SqlConnection(connstr))
			{
				SqlCommand cmd = new SqlCommand();

				cmd.Connection = conn;

				foreach (var poco in items)
				{
					cmd.CommandText = @" DELETE FROM [dbo].[Applicant_Skills]
										WHERE ( [Id] = @Id ) ";

					cmd.Parameters.AddWithValue("@Id", poco.Id);

					conn.Open();
					cmd.ExecuteNonQuery();
					conn.Close();
				}
			}

		}

		public void Update(params ApplicantSkillPoco[] items)
		{
			using (SqlConnection conn = new SqlConnection(connstr))
			{

				SqlCommand cmd = new SqlCommand();
				cmd.Connection = conn;
				foreach (var poco in items)
				{
					cmd.CommandText = @" UPDATE [dbo].[Applicant_Skills]
									   SET [Id] = @Id
										  ,[Applicant] = @Applicant
										  ,[Skill] = @Skill
										  ,[Skill_Level] = @Skill_Level
										  ,[Start_Month] = @Start_Month
										  ,[Start_Year] = @Start_Year
										  ,[End_Month] = @End_Month
										  ,[End_Year] = @End_Year
									 WHERE [Id] = @Id ";

					cmd.Parameters.AddWithValue("@Id", poco.Id);
					cmd.Parameters.AddWithValue("@Applicant", poco.Applicant);
					cmd.Parameters.AddWithValue("@Skill", poco.Skill);
					cmd.Parameters.AddWithValue("@Skill_Level", poco.SkillLevel);
					cmd.Parameters.AddWithValue("@Start_Month", poco.StartMonth);
					cmd.Parameters.AddWithValue("@Start_Year", poco.StartYear);
					cmd.Parameters.AddWithValue("@End_Month", poco.EndMonth);
					cmd.Parameters.AddWithValue("@End_Year", poco.EndYear);

					conn.Open();
					cmd.ExecuteNonQuery();
					conn.Close();


				}


			}
		}
	}
}
