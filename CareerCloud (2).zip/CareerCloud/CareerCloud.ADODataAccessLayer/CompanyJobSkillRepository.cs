﻿using CareerCloud.DataAccessLayer;
using CareerCloud.Pocos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq.Expressions;
using System.Data.SqlClient;

namespace CareerCloud.ADODataAccessLayer
{
	public class CompanyJobSkillRepository : BaseADOclass, IDataRepository<CompanyJobSkillPoco>
	{
		public void Add(params CompanyJobSkillPoco[] items)
		{
			using (SqlConnection conn = new SqlConnection(connstr))
			{
				SqlCommand cmd = new SqlCommand();
				cmd.Connection = conn;

				foreach (CompanyJobSkillPoco pocos in items)

				{
					cmd.CommandText = @"INSERT INTO [dbo].[Company_Job_Skills]
												   ([Id]
												   ,[Job]
												   ,[Skill]
												   ,[Skill_Level]
												   ,[Importance])
											 VALUES
												   (@Id
												   ,@Job
												   ,@Skill
												   ,@Skill_Level
												   ,@Importance)";

					cmd.Parameters.AddWithValue("@Id", pocos.Id);
					cmd.Parameters.AddWithValue("@Job", pocos.Job);
					cmd.Parameters.AddWithValue("@Skill", pocos.Skill);
					cmd.Parameters.AddWithValue("@Skill_Level", pocos.SkillLevel);
					cmd.Parameters.AddWithValue("@Importance", pocos.Importance);

					conn.Open();
					cmd.ExecuteNonQuery();
					conn.Close();

				}
			}
		}

		public void CallStoredProc(string name, params Tuple<string, string>[] parameters)
		{
			throw new NotImplementedException();
		}

		public IList<CompanyJobSkillPoco> GetAll(params Expression<Func<CompanyJobSkillPoco, object>>[] navigationProperties)
		{
			using (SqlConnection conn = new SqlConnection(connstr))
			{
				
				SqlCommand cmd = new SqlCommand();
				cmd.Connection = conn;
				cmd.CommandText = @"SELECT [Id]
										  ,[Job]
										  ,[Skill]
										  ,[Skill_Level]
										  ,[Importance]
										  ,[Time_Stamp]
									  FROM [dbo].[Company_Job_Skills]";

				int counter = 0;
				CompanyJobSkillPoco[] pocos = new CompanyJobSkillPoco [6000];
				conn.Open();
				SqlDataReader sqrd = cmd.ExecuteReader();

				while (sqrd.Read())
				{
					CompanyJobSkillPoco poco = new CompanyJobSkillPoco();

					poco.Id = sqrd.GetGuid(0);
					poco.Job = sqrd.GetGuid(1);
					poco.Skill = sqrd.GetString(2);
					poco.SkillLevel= sqrd.GetString(3);
					poco.Importance = sqrd.GetInt32(4);
					poco.TimeStamp = (byte[])sqrd[5];

					pocos[counter] = poco;

					counter++;

				}
				return pocos.Where(a => a != null).ToList();


			}
		}

		public IList<CompanyJobSkillPoco> GetList(Func<CompanyJobSkillPoco, bool> where, params Expression<Func<CompanyJobSkillPoco, object>>[] navigationProperties)
		{
			throw new NotImplementedException();
		}

		public CompanyJobSkillPoco GetSingle(Func<CompanyJobSkillPoco, bool> where, params Expression<Func<CompanyJobSkillPoco, object>>[] navigationProperties)
		{
			CompanyJobSkillPoco[] pocos = GetAll().ToArray();
			return pocos.Where(where).ToList().FirstOrDefault();
		}

		public void Remove(params CompanyJobSkillPoco[] items)
		{
			using (SqlConnection conn = new SqlConnection(connstr))
			{
				SqlCommand cmd = new SqlCommand();

				cmd.Connection = conn;
				foreach (var poco in items)
				{
					cmd.CommandText = @"DELETE FROM [dbo].[Company_Job_Skills]
										WHERE ( [Id] = @Id ) ";

					cmd.Parameters.AddWithValue("@Id", poco.Id);

					conn.Open();
					cmd.ExecuteNonQuery();
					conn.Close();
				}
			}
		}

		public void Update(params CompanyJobSkillPoco[] items)
		{
			using (SqlConnection conn = new SqlConnection(connstr))
			{

				SqlCommand cmd = new SqlCommand();
				cmd.Connection = conn;
				foreach (var poco in items)
				{
					cmd.CommandText = @"UPDATE [dbo].[Company_Job_Skills]
										   SET [Id] = @Id
											  ,[Job] =@Job
											  ,[Skill] =@Skill
											  ,[Skill_Level] =@Skill_Level
											  ,[Importance] =@Importance
									      WHERE [Id] = @Id ";

					cmd.Parameters.AddWithValue("@Id", poco.Id);
					cmd.Parameters.AddWithValue("@Job", poco.Job);
					cmd.Parameters.AddWithValue("@Skill", poco.Skill);
					cmd.Parameters.AddWithValue("@Skill_Level", poco.SkillLevel);
					cmd.Parameters.AddWithValue("@Importance", poco.Importance);


					conn.Open();
					cmd.ExecuteNonQuery();
					conn.Close();

				}


			}
		}
	}
}
